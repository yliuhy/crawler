package Parser;

public interface Parser {
    void parse(String content);
}