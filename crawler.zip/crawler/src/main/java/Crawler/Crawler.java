package Crawler;

public interface Crawler {
    String crawl(String url);
}